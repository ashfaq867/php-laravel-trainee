<?php
// <----database configuration--->
$server="localhost";
$user="root";
$password="";
$database="assignment";
$conn=mysqli_connect($server,$user,$password,$database) or die("Connection Failed!");


?>